// Cleanup script to remove any debug elements or animations
document.addEventListener('DOMContentLoaded', function() {
    // Hide weather animation container
    const weatherAnimation = document.getElementById('weatherAnimation');
    if (weatherAnimation) {
        weatherAnimation.style.display = 'none';
        weatherAnimation.innerHTML = '';
    }
    
    // Remove any unexpected absolute positioned elements
    const unwantedElements = document.querySelectorAll('div:not(.clock *):not(.hand):not(.center-dot):not(.link-item *):not(.link-item)[style*="position: absolute"], div:not(.clock *):not(.hand):not(.center-dot):not(.link-item *):not(.link-item)[style*="position:absolute"]');
    unwantedElements.forEach(el => {
        if (!el.parentElement || (!el.parentElement.classList.contains('clock') && !el.parentElement.classList.contains('link-item'))) {
            el.style.display = 'none';
        }
    });
    
    // Disable animations that might be causing issues
    document.querySelectorAll('[style*="animation"]').forEach(el => {
        if (!el.classList.contains('outer-dial') && 
            !el.classList.contains('inner-dial') && 
            !el.classList.contains('hand') &&
            !el.classList.contains('link-item') && 
            !el.tagName === 'I') {
            el.style.animation = 'none';
            el.style.animationName = 'none';
            el.style.animationDuration = '0s';
        }
    });
    
    // Remove any inline styles with outline or border except for link items
    document.querySelectorAll('[style*="outline"], [style*="border"]').forEach(el => {
        if (!el.classList.contains('hand') && 
            !el.classList.contains('link-item') && 
            !el.parentElement?.classList.contains('link-item') && 
            (!el.parentElement || !el.parentElement.classList.contains('clock'))) {
            el.style.outline = 'none';
            el.style.border = 'none';
        }
    });
    
    // Remove any glowing elements in the weather section
    const weatherSection = document.querySelector('.weather-section');
    if (weatherSection) {
        const glowingElements = weatherSection.querySelectorAll('div:not(.weather-item):not(.aqi):not(.temperature):not(.weather-details):not(.aqi-label):not(.aqi-value):not(.aqi-status)');
        glowingElements.forEach(el => {
            el.style.display = 'none';
        });
    }

    // Ensure link items display correctly
    document.querySelectorAll('.link-item').forEach(el => {
        el.style.display = 'flex';
        el.style.flexDirection = 'column';
        el.style.alignItems = 'center';
        el.style.opacity = '1';
        el.style.visibility = 'visible';
        el.style.border = '1px solid rgba(139, 107, 47, 0.1)';
        el.style.backgroundColor = 'rgba(255, 255, 255, 0.9)';
        el.style.borderRadius = '8px';
        el.style.padding = '0.6rem';
        el.style.minHeight = '60px';
    });

    // Ensure icons in link items are visible
    document.querySelectorAll('.link-item i').forEach(el => {
        el.style.display = 'inline-block';
        el.style.opacity = '1';
        el.style.visibility = 'visible';
        el.style.fontSize = '1.1rem';
        el.style.color = 'var(--accent-primary)';
    });
}); 